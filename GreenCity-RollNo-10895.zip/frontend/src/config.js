
export const API_BASE_URL =
  (import.meta.env.VITE_API_URL || "http://localhost:5000/api")
    .replace(/\/+$/, "");

export default API_BASE_URL;
